﻿import pathlib
import PyPDF2
p = pathlib.Path(r'c:\Users\yoshi\Downloads\fs labs (3)\fs labs\2400032783_FSAD_SKILL_11.pdf')
reader = PyPDF2.PdfReader(str(p))
print('FOUND')
print(len(reader.pages))
for i, page in enumerate(reader.pages, start=1):
    print('===PAGE %d===' % i)
    text = page.extract_text()
    print(text or '[NO TEXT]')
